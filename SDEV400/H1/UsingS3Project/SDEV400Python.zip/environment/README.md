Please ensure that the "environment" folder is opened in VS code or is the current directory, 
run using_s3.py inside the "environment" folder and not the Homework1 folder.
If not, the files will not load, as the path for the files (lotus.jpg, sasuke.jpg,.etc) is listed as Homework1/file_name
