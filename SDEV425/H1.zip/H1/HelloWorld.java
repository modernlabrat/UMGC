/*
 * Author: Kyra Samuel
 * Project: Homework 1
 * Class: HelloWorld.java 
 * Instructor: Craig Poma
 * Created On: 04/14/2022
 */
import java.util.Date;
import java.util.Scanner;

public class HelloWorld {  
  public void run() {
    Date now = new Date();
    System.out.println("Hello World, it is " + now.toString());
  }
}
