/*
 * Author: Kyra Samuel
 * File: Status.java
 * Description: Enum class for Media Status
 */

public enum Status {
    AVAILABLE,
    OUT_OF_STOCK
}
