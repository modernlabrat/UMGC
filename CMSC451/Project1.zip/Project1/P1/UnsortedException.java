package P1;
/*
 * Kyra Samuel
 * CMSC 451
 * UnsortedException.java
 */
public class UnsortedException extends Exception {
  public UnsortedException(String errorMessage) {
    super(errorMessage);
  }
}