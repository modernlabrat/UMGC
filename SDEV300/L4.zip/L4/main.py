import lab_four as lab
import sys

if __name__ == "__main__":
    try:
        lab.run()
    except KeyboardInterrupt:
        sys.exit(0)