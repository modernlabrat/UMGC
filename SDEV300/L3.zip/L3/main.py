import lab_three as lab
import sys

if __name__ == '__main__':
    try:
        lab.run()
    except KeyboardInterrupt:
        sys.exit()
